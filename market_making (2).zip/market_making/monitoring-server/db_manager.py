

## We have to create a redis monitoring service
