
import subprocess
from time import sleep

if __name__ == "__main__":
    #while (True):
        subprocess.run("python protocol.py")
        #sleep(900)